import pymysql

rds_host  = 'database-2.cm7m35pgawvs.eu-west-2.rds.amazonaws.com'
name = 'admin'
password = 'password'
db_name = 'lambda'
port = 3306

conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)

def lambda_handler(event, context):
    """
    This function inserts content into mysql RDS instance
    """
    with conn.cursor() as cur:
        cur.execute('UPDATE Employee5 SET Name = 'Joseph' WHERE Name = 'Joe'')
        conn.commit()
    return "Success" 
